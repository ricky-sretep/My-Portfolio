# === The "App" Python File === #
# Author: Richard Peters #

# --- The Imports --- #
from flask import Flask

# --- The Initialization --- #
app = Flask(__name__)

# --- The Routes --- #


# The Index Route #
@app.route('/')
def index():
    return '<h1>Hello World!</h1>'


# The View Function #
@app.route('/view/<view>')
def view(view):
    return '<h1> This is ' + view + ' function.</h1>'


# --- The Server Starter --- #
if __name__ == '__main__':
    app.run(debug=True)
